﻿var LOAD_DEBUG_JSXGETURL;
var JSXGetURL;
var TIGHTENER;
var IS_INDESIGN_SERVER;

if (LOAD_DEBUG_JSXGETURL || "undefined" == typeof(JSXGetURL)) {

    JSXGetURL = function() {

        var scriptFolder = File($.fileName).parent;
        Folder.current = scriptFolder;

        var lib = undefined;
        var isDebug = LOAD_DEBUG_JSXGETURL;
        var configSuffix = (isDebug ? "D" : "R");

        var isWin = (File.fs == "Windows");
        var fileNameExtension = (isWin) ? ".dll" : ".framework";
        var x64Suffix = "_x64";
        var libFileName = "TightenerESDLL";

        var lib64Filename = libFileName + x64Suffix + configSuffix + fileNameExtension;

        var libPath64;
        if (isDebug) {
            if (isWin) {
                libPath64 = Folder.current.parent.parent.parent.fsName + "/TightenerDLL/VisualStudio/Compiled/x64/esdlldebug/" + lib64Filename;
            }
            else {
                libPath64 = Folder.current.parent.parent.parent.fsName + "/TightenerDLL/Xcode/Compiled/Debug/" + lib64Filename;
            }
        }
        else {
            var appSideJSXGetURL = Folder(app.filePath + "/Scripts/JSXGetURL/");
            if (isWin) {
                libPath64 = appSideJSXGetURL + "win64/" + lib64Filename;
                if (! File(libPath64).exists) {
                    libPath64 = Folder.current.fsName + "\\win64\\" + lib64Filename;
                }
            }
            else {
                libPath64 = appSideJSXGetURL + "mac64/" + lib64Filename;
                if (! File(libPath64).exists) {
                    libPath64 = Folder.current.fsName + "/mac64/" + lib64Filename;
                }
            }
        }

        function tryLib(libPath) {
            var file = new File(libPath);
            var lib = undefined;
            if (file.exists) {
                try {
                    lib = new ExternalObject("lib:" + file.fsName);
                }
                catch (err) {
                }
            }
            return lib;
        }

        // Use previously loaded lib, if any
        lib = JSXGetURL.lib;
        if (! lib) {
            lib = tryLib(libPath64);
            JSXGetURL.lib = lib;
        }

        // Re-enable JSXGetURL (set disable = false) in case it was disabled at the
        // end of the previous script run to protect from
        // ESTK crashes
        if (lib) {
            lib.disable(false);
        }

        TIGHTENER = lib;
        return lib;
    };

}

if (JSXGetURL.isInDesignServer === undefined) {
    JSXGetURL.isInDesignServer = false;
    try {
        if ("serverSettings" in app && app.name.toLowerCase().indexOf("indesign") >= 0) {
            JSXGetURL.isInDesignServer = true;
        }
    }
    catch (err) {}
}

JSXGetURL